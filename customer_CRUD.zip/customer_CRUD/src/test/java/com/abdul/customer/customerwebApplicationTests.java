package com.abdul.customer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class customerwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
