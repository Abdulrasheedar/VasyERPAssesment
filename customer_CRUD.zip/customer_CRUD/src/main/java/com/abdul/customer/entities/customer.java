package com.abdul.customer.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.SecondaryTable;
import javax.persistence.Table;

@Entity
@Table(name="customer")
@SecondaryTable(name="customer_Address", pkJoinColumns = @PrimaryKeyJoinColumn(name = "id"))
public class customer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	@Column(name="name")
	private String name;
	@Column(name="mobileno")
	private Long mobileno;
	@Column(name="emailid")
	private String emailid;
	@Column(name="Address", table = "customer_Address")
	private String Address;
	@Column(name="State", table = "customer_Address")
	private String State;
	@Column(name="city", table = "customer_Address")
	private String city;
	@Column(name="pincode", table = "customer_Address")
	private Long pincode;
		
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getmobileNo() {
		return mobileno;
	}
	public void setmobileNo(Long mobileno) {
		this.mobileno = mobileno;
	}
	public String getEmail() {
		return emailid;
	}
	public void setEmail(String emailid) {
		this.emailid = emailid;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String Address) {
		this.Address = Address;
	}
	public String getState() {
		return State;
	}
	public void setState(String State) {
		this.State = State;
	}
	public String getcity() {
		return city;
	}
	public void setcity(String city) {
		this.city = city;
	}
	public Long getpinCode() {
		return pincode;
	}
	public void setpinCode(Long pincode) {
		this.pincode= pincode;
	}
	@Override
	public String toString() {
		return "customer [id=" + id + ", name=" + name + ", mobileno=" + mobileno + ",emailid=" + emailid + ",Address=" +Address+ ",State=" +State+ ",city=" +city+ ",pincode=" +pincode+ "]";
	}
}
