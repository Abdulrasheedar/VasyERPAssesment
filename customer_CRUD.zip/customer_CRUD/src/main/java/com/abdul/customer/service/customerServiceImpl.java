package com.abdul.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abdul.customer.entities.customer;
import com.abdul.customer.repos.customerRepository;

@Service
public class customerServiceImpl implements customerService {
	
	@Autowired
	private customerRepository repository;
	
	@Override
	public customer saveCustomer(customer customer) {
		return repository.save(customer);
	}

	@Override
	public customer updateCustomer(customer customer) {
		return repository.save(customer);
	}
	@Override
	public void deleteCustomer(customer customer) {
		repository.delete(customer);
	}
	@Override
	public customer getCustomerById(int id) {
		return repository.findById(id).get();
	}
	@Override
	public List<customer> getAllCustomers() {
		return repository.findAll();
	}

	

}
