package com.abdul.customer.service;

import java.util.List;

import com.abdul.customer.entities.customer;

public interface customerService {

		customer saveCustomer(customer customer);
		customer updateCustomer(customer customer);
		void deleteCustomer(customer customer);
		customer getCustomerById(int id);
		List<customer> getAllCustomers();
}
