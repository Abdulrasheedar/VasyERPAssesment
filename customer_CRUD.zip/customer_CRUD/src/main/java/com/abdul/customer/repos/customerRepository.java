package com.abdul.customer.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abdul.customer.entities.customer;

public interface customerRepository extends JpaRepository<customer, Integer> {

}
