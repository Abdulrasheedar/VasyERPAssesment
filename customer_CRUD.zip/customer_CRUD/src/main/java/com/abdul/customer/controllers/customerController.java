package com.abdul.customer.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.abdul.customer.entities.customer;
import com.abdul.customer.repos.customerRepository;
import com.abdul.customer.service.customerService;


@Controller
public class customerController {
	
	@Autowired
	customerService service;
	
	@Autowired
	customerRepository repository;
	
	@RequestMapping("/showCreate")
	public String showCreate() {
		return "createCustomer";
	}
	
	@RequestMapping("/saveCustomer")
	public String saveCustomer(@ModelAttribute("customer") customer customer, ModelMap modelMap) {
		customer customerSaved = service.saveCustomer(customer);
		String msg ="customer save with id: "+customerSaved.getId();
		modelMap.addAttribute("msg", msg);
		return "createCustomer";
	}
	
	@RequestMapping("/displayCustomers")
	public String displayCustomers(ModelMap modelMap) {
		List<customer> customers = service.getAllCustomers();
		modelMap.addAttribute("customers", customers);
		return "displayCustomers";
	}
	
	@RequestMapping("/deleteCustomer")
	public String deleteCustomer(@RequestParam("id") int id, ModelMap modelMap) {
	//	customer customer = service.getcustomerById(id);
		customer customer = new customer();
		customer.setId(id);
		service.deleteCustomer(customer);
		List<customer> customers = service.getAllCustomers();
		modelMap.addAttribute("customers", customers);
		return "displayCustomers";
	}
	
	@RequestMapping("/showUpdate")
	public String showUpdate(@RequestParam("id") int id,ModelMap modelMap) {
		customer customer = service.getCustomerById(id);
		modelMap.addAttribute("customer", customer);
		return "updateCustomer";
	}
	@RequestMapping("/updateCustomers")
	public String updateCustomer(@ModelAttribute("customer") customer customer, ModelMap modelMap) {
		service.updateCustomer(customer);
		List<customer> customers = service.getAllCustomers();
		modelMap.addAttribute("customers", customers);
		return "displayCustomers";
	}
}
